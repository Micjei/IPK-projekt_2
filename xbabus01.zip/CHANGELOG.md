Byte streaming byl málo testován a je možné, že nefunguje, jak by měl.
username, secret, displayname je potřeba napsat v tomto pořadí.